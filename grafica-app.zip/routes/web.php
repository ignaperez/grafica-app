<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\OrdenTrabajoController;
use App\Http\Controllers\TrabajoController;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\ListaPrecioController;
use App\Http\Controllers\FichadaController;
use App\Http\Controllers\EmpleadoController;

/*
|--------------------------------------------------------------------------
| Rutas públicas (sin login)
|--------------------------------------------------------------------------
*/

Route::get('/', fn () => view('welcome'));

// Kiosco de fichada — tablet en recepción, sin autenticación
Route::get('/fichar',  [FichadaController::class, 'showKiosk'])->name('fichar.form');
Route::post('/fichar', [FichadaController::class, 'store'])->name('fichar.store');

/*
|--------------------------------------------------------------------------
| Rutas autenticadas — generales
|--------------------------------------------------------------------------
*/

Route::middleware('auth')->group(function () {

    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Perfil
    Route::get('/profile',    [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile',  [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // Rutas de prueba — podés borrarlas en producción
    Route::get('/select2-test', fn () => view('select2-test'))->name('select2-test');
    Route::get('/ordenes-test', function () {
        $ordenes = App\Models\OrdenTrabajo::with('cliente')->limit(5)->get();
        return view('ordenes-test', compact('ordenes'));
    })->name('ordenes.test');

});

/*
|--------------------------------------------------------------------------
| RRHH (autenticado)
|--------------------------------------------------------------------------
*/

Route::middleware('auth')->prefix('rrhh')->name('rrhh.')->group(function () {

    // Dashboard RRHH
    Route::get('/', [FichadaController::class, 'dashboard'])->name('dashboard');

    // Fichadas
    Route::get('/fichadas',     [FichadaController::class, 'index'])->name('fichadas.index');
    Route::get('/fichadas/hoy', [FichadaController::class, 'hoy'])->name('fichadas.hoy');

    // Empleados ABM
    Route::get('/empleados',                  [EmpleadoController::class, 'index'])->name('empleados.index');
    Route::get('/empleados/crear',            [EmpleadoController::class, 'create'])->name('empleados.create');
    Route::post('/empleados',                 [EmpleadoController::class, 'store'])->name('empleados.store');
    Route::get('/empleados/{empleado}/edit',  [EmpleadoController::class, 'edit'])->name('empleados.edit');
    Route::put('/empleados/{empleado}',       [EmpleadoController::class, 'update'])->name('empleados.update');
    Route::delete('/empleados/{empleado}',    [EmpleadoController::class, 'destroy'])->name('empleados.destroy');

    // Reportes y liquidaciones por empleado
    Route::get('/empleados/{empleado}/fichadas', [FichadaController::class, 'porEmpleado'])->name('empleados.fichadas');
    Route::get('/empleados/{empleado}/liquidar', [EmpleadoController::class, 'liquidar'])->name('empleados.liquidar');
    Route::post('/empleados/{empleado}/pagos',   [EmpleadoController::class, 'registrarPago'])->name('empleados.pagos.store');

});

/*
|--------------------------------------------------------------------------
| AJAX — búsquedas para Select2 (autenticado)
|--------------------------------------------------------------------------
*/

Route::middleware('auth')->group(function () {

    Route::get('/clientes/search',      [ClienteController::class,   'search'])->name('clientes.search');
    Route::get('/productos/search',     [ProductoController::class,  'search'])->name('productos.search');
    Route::get('/listas-precios/buscar',[ListaPrecioController::class,'search'])->name('listas-precios.search');

});

/*
|--------------------------------------------------------------------------
| Recursos — Admin
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'rol:admin'])->group(function () {

    Route::get('/admin', fn () => 'Bienvenido administrador.');

    Route::resource('clientes', ClienteController::class);

});

/*
|--------------------------------------------------------------------------
| Recursos — Admin + Ventas
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'rol:admin,ventas'])->group(function () {

    Route::get('/ventas', fn () => 'Bienvenido ventas.');

    // Órdenes de trabajo
    Route::resource('ordenes-trabajo', OrdenTrabajoController::class);

    // Trabajos de una orden (pantalla de carga)
    Route::get('/ordenes-trabajo/{orden}/trabajos', [OrdenTrabajoController::class, 'trabajos'])
        ->name('ordenes.trabajos');

    // Cambiar estado de una orden
    Route::patch('/ordenes-trabajo/{id}/estado', [OrdenTrabajoController::class, 'cambiarEstado'])
        ->name('ordenes-trabajo.estado');

    // Trabajos — rutas especiales ANTES del resource para evitar conflictos
    Route::post('/trabajos/ajax-store',    [TrabajoController::class, 'ajaxStore'])->name('trabajos.ajax-store');
    Route::post('/trabajos/store-multiples',[TrabajoController::class, 'storeMultiples'])->name('trabajos.store-multiples');
    Route::post('/trabajos/{id}/terminar', [TrabajoController::class, 'marcarTerminado'])->name('trabajos.terminar');
    Route::get('/trabajos/create/{ordenTrabajo}', [TrabajoController::class, 'create'])->name('trabajos.create');

    Route::resource('trabajos', TrabajoController::class);

    // Productos y listas de precios
    Route::resource('productos',     ProductoController::class);
    Route::resource('listas-precios', ListaPrecioController::class);

});

/*
|--------------------------------------------------------------------------
| Admin + Producción
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'rol:admin,produccion'])->group(function () {

    Route::get('/produccion', fn () => 'Bienvenido producción o admin.');

});

/*
|--------------------------------------------------------------------------
| Auth (Breeze)
|--------------------------------------------------------------------------
*/

require __DIR__ . '/auth.php';
