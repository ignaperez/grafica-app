@extends('layouts.app')

@section('content')
<div class="container">
    <h3>Editar Trabajo #{{ $trabajo->id }}</h3>

    <form action="{{ route('trabajos.update', ['trabajo' => $trabajo->id]) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="mb-3">
            <label for="producto_id">Producto</label>
            <select name="cliente_id" class="form-control" required>
    @foreach($clientes as $cli)
        <option value="{{ $cli->id }}" {{ $orden->cliente_id == $cli->id ? 'selected' : '' }}>
            {{ $cli->nombre }}
        </option>
    @endforeach
</select>
        </div>

        <div class="mb-3">
            <label for="descripcion">Observaciones</label>
            <textarea name="descripcion" id="descripcion" class="form-control">{{ old('descripcion', $trabajo->descripcion) }}</textarea>
        </div>

        <div class="row">
            <div class="col">
                <label for="ancho">Ancho (m)</label>
                <input type="number" step="0.01" name="ancho" id="ancho" class="form-control"
                       value="{{ old('ancho', $trabajo->ancho) }}">
            </div>
            <div class="col">
                <label for="alto">Alto (m)</label>
                <input type="number" step="0.01" name="alto" id="alto" class="form-control"
                       value="{{ old('alto', $trabajo->alto) }}">
            </div>
        </div>

        <div class="mt-3">
            <label for="cantidad">Cantidad</label>
            <input type="number" name="cantidad" id="cantidad" class="form-control"
                   value="{{ old('cantidad', $trabajo->cantidad) }}">
        </div>

        <div class="mt-3">
            <label for="fecha_entrega">Fecha de Entrega</label>
            <input type="date" name="fecha_entrega" id="fecha_entrega" class="form-control"
                   value="{{ old('fecha_entrega', $trabajo->fecha_entrega ? \Carbon\Carbon::parse($trabajo->fecha_entrega)->format('Y-m-d') : '') }}">
        </div>

        <div class="mt-4">
            <button type="submit" class="btn btn-primary">Guardar cambios</button>
            <a href="{{ url()->previous() }}" class="btn btn-secondary">Cancelar</a>
        </div>
    </form>
</div>
@endsection
