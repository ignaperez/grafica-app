@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-4">Orden de Trabajo #{{ $orden_trabajo->id }}</h2>
    
    <div class="card mb-4">
        <div class="card-body">
            <p><strong>Cliente:</strong> {{ $orden_trabajo->cliente->nombre ?? 'Sin cliente' }}</p>
            <p><strong>Fecha de recepción:</strong> {{ $orden_trabajo->fecha_recibido ? \Carbon\Carbon::parse($orden_trabajo->fecha_recibido)->format('d/m/Y') : '-' }}</p>
            <p><strong>Estado:</strong> {{ ucfirst($orden_trabajo->estado) }}</p>
            <p><strong>Observaciones:</strong> {{ $orden_trabajo->observaciones ?? '-' }}</p>
            @if ($orden_trabajo->fotos->count() > 0)
    <div>
        <label>Fotos:</label>
        <div class="d-flex flex-wrap gap-2">
            @foreach ($orden_trabajo->fotos as $foto)
                <img src="{{ asset('storage/' . $foto->ruta) }}" alt="Foto" width="200">
            @endforeach
        </div>
    </div>
@endif
        </div>
    </div>
    <h4>Trabajos Asociados</h4>

@if ($orden_trabajo->trabajos->count())
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Producto</th>
                <th>Ancho (m)</th>
                <th>Alto (m)</th>
                <th>Cantidad</th>
                <th>Descripcion</th>
                <th>Consumo (m²)</th>
            </tr>
        </thead>
        <tbody>
        
            @foreach($orden_trabajo->trabajos as $trabajo)
                <tr>
                    <td>{{ $trabajo->producto->nombre ?? $trabajo->tipo }}</td>
                    <td>{{ $trabajo->ancho ?? '-' }}</td>
                    <td>{{ $trabajo->alto ?? '-' }}</td>
                    <td>{{ $trabajo->cantidad }}</td>
                    <td>{{ $trabajo->descripcion ?? '-' }}</td>
                    <td>
                    @php
                                $consumo = 0;
                                if ($trabajo->ancho && $trabajo->alto) {
                                    $consumo = round($trabajo->ancho * $trabajo->alto * $trabajo->cantidad, 2);
                                }
                         
                        @endphp
                        {{ $consumo }} m²
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@else
    <p>No hay trabajos registrados.</p>
@endif

@endsection
