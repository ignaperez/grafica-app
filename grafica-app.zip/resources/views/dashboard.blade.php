@extends('layouts.app')

@section('page-title', 'Dashboard')

@section('topbar-actions')
    <a href="{{ route('ordenes-trabajo.create') }}" class="gbtn gbtn-primary">+ Nueva orden</a>
@endsection

@section('content')

{{-- CARDS DE ESTADO --}}
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:24px">

    <div class="gcard" style="border-top:2px solid #333">
        <div class="gcard-bd" style="padding:18px 20px">
            <div class="mono" style="font-size:30px;font-weight:500;color:#666;line-height:1;margin-bottom:5px">{{ $contadores['borrador'] }}</div>
            <div style="font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:#444">Borrador</div>
        </div>
    </div>

    <div class="gcard" style="border-top:2px solid #d4900a">
        <div class="gcard-bd" style="padding:18px 20px">
            <div class="mono" style="font-size:30px;font-weight:500;color:#d4900a;line-height:1;margin-bottom:5px">{{ $contadores['en_produccion'] }}</div>
            <div style="font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:#444">En producción</div>
        </div>
    </div>

    <div class="gcard" style="border-top:2px solid #4caf6e">
        <div class="gcard-bd" style="padding:18px 20px">
            <div class="mono" style="font-size:30px;font-weight:500;color:#4caf6e;line-height:1;margin-bottom:5px">{{ $contadores['lista'] }}</div>
            <div style="font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:#444">Listas p/ entregar</div>
        </div>
    </div>

    <div class="gcard" style="border-top:2px solid #4a8fd4">
        <div class="gcard-bd" style="padding:18px 20px">
            <div class="mono" style="font-size:30px;font-weight:500;color:#4a8fd4;line-height:1;margin-bottom:5px">{{ $contadores['entregada'] }}</div>
            <div style="font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:#444">Entregadas</div>
        </div>
    </div>

</div>

{{-- LISTADO --}}
<div class="gcard">
    <div class="gcard-hd">
        <span class="gcard-title">Órdenes activas</span>
    </div>
    @if($ordenes->isEmpty())
        <div class="gcard-bd" style="text-align:center;color:#444;padding:48px 20px">
            No hay órdenes activas.
        </div>
    @else
        <table class="gtable">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Cliente</th>
                    <th>Fecha</th>
                    <th>Estado</th>
                    <th>Progreso</th>
                    <th>Trabajos</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                @foreach($ordenes as $orden)
                    @php
                        $total      = $orden->trabajos->count();
                        $terminados = $orden->trabajos->whereIn('estado', ['terminado','entregado'])->count();
                        $pct        = $total > 0 ? round($terminados / $total * 100) : 0;
                    @endphp
                    <tr>
                        <td class="mono" style="color:#555;font-size:12px">#{{ str_pad($orden->id, 3, '0', STR_PAD_LEFT) }}</td>
                        <td>
                            <div style="font-weight:500">{{ $orden->cliente->nombre ?? 'Sin cliente' }}</div>
                            @if($orden->observaciones)
                                <div style="font-size:12px;color:#555;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:220px">{{ $orden->observaciones }}</div>
                            @endif
                        </td>
                        <td class="mono txm" style="font-size:12px">{{ \Carbon\Carbon::parse($orden->fecha_recibido)->format('d/m/y') }}</td>
                        <td>
                            <span class="badge-estado be-{{ $orden->estado }}">
                                {{ ['borrador'=>'Borrador','en_produccion'=>'En producción','lista'=>'Lista','entregada'=>'Entregada','cancelada'=>'Cancelada'][$orden->estado] ?? $orden->estado }}
                            </span>
                        </td>
                        <td style="min-width:130px">
                            @if($total > 0)
                                <div class="gprog" style="margin-bottom:4px">
                                    <div class="gprog-fill {{ $pct == 100 ? 'done' : '' }}" style="width:{{ $pct }}%"></div>
                                </div>
                                <div class="mono" style="font-size:10px;color:#444">{{ $terminados }}/{{ $total }} trabajos</div>
                            @else
                                <span style="font-size:12px;color:#333">Sin trabajos</span>
                            @endif
                        </td>
                        <td style="max-width:180px">
                            @foreach($orden->trabajos->take(2) as $t)
                                <div style="font-size:12px;color:#555">· {{ $t->descripcion ?? $t->tipo ?? '—' }}</div>
                            @endforeach
                            @if($orden->trabajos->count() > 2)
                                <div style="font-size:11px;color:#3a3a3a">+{{ $orden->trabajos->count() - 2 }} más</div>
                            @endif
                        </td>
                        <td style="text-align:right;white-space:nowrap">
                            <a href="{{ route('ordenes-trabajo.show', $orden->id) }}" class="gbtn gbtn-ghost gbtn-sm">Ver</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif
</div>

@endsection
