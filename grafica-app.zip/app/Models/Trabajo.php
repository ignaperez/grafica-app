<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Trabajo extends Model
{
    //relaciones
    protected $fillable = [
        'orden_trabajo_id',
        'producto_id',
        'tipo',
        'descripcion',
        'medidas',
        'cantidad',
        'estado',
        'fecha_entrega',
        'precio_unitario',
        'ancho',
        'alto',
    ];

    public function producto()
    {
        return $this->belongsTo(Producto::class);
    }
    public function orden()
    {
        return $this->belongsTo(OrdenTrabajo::class, 'orden_trabajo_id');
    }

}
