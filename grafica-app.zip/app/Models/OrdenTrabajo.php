<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\Cliente;
use App\Models\Trabajo;

class OrdenTrabajo extends Model
{
    use HasFactory;

    protected $table = 'orden_trabajos';
    

    protected $fillable = [
        'cliente_id',
        'fecha_recibido',
        'observaciones',
        'estado',
        'activo',
    ];

    // Protección extra para evitar pisar relaciones
    protected $guarded = ['cliente'];

    // RELACIONES

    

    public function trabajos()
{
    return $this->hasMany(Trabajo::class);
}

    public function cliente()
{
    return $this->belongsTo(\App\Models\Cliente::class, 'cliente_id', 'id')->withDefault([
        'nombre' => 'Sin especificar',
    ]);
}
public function fotos()
{
    return $this->hasMany(OrdenFoto::class);
}

}
