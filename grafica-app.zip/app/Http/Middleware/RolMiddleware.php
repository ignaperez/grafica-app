<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RolMiddleware
{
    public function handle(Request $request, Closure $next, ...$roles): Response
    {
        $usuario = auth()->user();

        // Aplanamos por si los roles vienen como 'admin,ventas' en vez de dos args separados
        $rolesPermitidos = [];
        foreach ($roles as $rol) {
            foreach (explode(',', $rol) as $r) {
                $rolesPermitidos[] = trim($r);
            }
        }

        if (!$usuario || !in_array($usuario->rol, $rolesPermitidos)) {
            abort(403, 'Acceso no autorizado.');
        }

        return $next($request);
    }
}
