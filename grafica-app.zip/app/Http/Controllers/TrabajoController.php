<?php

namespace App\Http\Controllers;

use App\Models\Trabajo;
use App\Models\OrdenTrabajo;
use App\Models\Producto;
use Illuminate\Http\Request;

class TrabajoController extends Controller
{
    /**
     * Crea un trabajo individual para una orden.
     * Unifica la lógica: siempre usa producto_id y calcula el precio
     * según la lista de precios del cliente.
     */
    public function store(Request $request)
    {
        $request->validate([
            'orden_trabajo_id' => 'required|exists:orden_trabajos,id',
            'producto_id'      => 'required|exists:productos,id',
            'cantidad'         => 'required|integer|min:1',
            'descripcion'      => 'nullable|string',
            'fecha_entrega'    => 'nullable|date',
            'ancho'            => 'required|numeric|min:0.01',
            'alto'             => 'required|numeric|min:0.01',
        ]);

        $orden    = OrdenTrabajo::with('cliente.listaPrecio')->findOrFail($request->orden_trabajo_id);
        $producto = Producto::findOrFail($request->producto_id);

        $multiplicador  = $orden->cliente->listaPrecio->multiplicador ?? 1;
        $precio_unitario = round($producto->precio * $multiplicador, 2);

        Trabajo::create([
            'orden_trabajo_id' => $orden->id,
            'producto_id'      => $producto->id,
            'tipo'             => $producto->tipo,
            'descripcion'      => $request->descripcion,
            'cantidad'         => $request->cantidad,
            'fecha_entrega'    => $request->fecha_entrega,
            'ancho'            => $request->ancho,
            'alto'             => $request->alto,
            'precio_unitario'  => $precio_unitario,
            'estado'           => 'pendiente',
        ]);

        $productos = Producto::orderBy('nombre')->get();

        return redirect()->route('ordenes.trabajos', ['orden' => $orden->id])
            ->with('success', 'Trabajo agregado.');
    }

    public function show($id)
    {
        $trabajo = Trabajo::with('producto', 'orden.cliente')->findOrFail($id);
        return view('trabajos.show', compact('trabajo'));
    }

    public function edit($id)
    {
        $orden = OrdenTrabajo::with(['trabajos.producto', 'cliente'])->findOrFail($id);
        return view('ordenes-trabajo.edit', compact('orden'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'producto_id'   => 'required|exists:productos,id',
            'descripcion'   => 'nullable|string',
            'ancho'         => 'nullable|numeric|min:0.01',
            'alto'          => 'nullable|numeric|min:0.01',
            'cantidad'      => 'required|integer|min:1',
            'fecha_entrega' => 'nullable|date',
        ]);

        $trabajo  = Trabajo::with('orden.cliente.listaPrecio')->findOrFail($id);
        $producto = Producto::findOrFail($request->producto_id);

        $multiplicador   = $trabajo->orden->cliente->listaPrecio->multiplicador ?? 1;
        $precio_unitario = round($producto->precio * $multiplicador, 2);

        $trabajo->update([
            'producto_id'    => $producto->id,
            'tipo'           => $producto->tipo,
            'descripcion'    => $request->descripcion,
            'ancho'          => $request->ancho,
            'alto'           => $request->alto,
            'cantidad'       => $request->cantidad,
            'fecha_entrega'  => $request->fecha_entrega,
            'precio_unitario'=> $precio_unitario,
        ]);

        return redirect()
            ->route('ordenes-trabajo.edit', ['ordenes_trabajo' => $trabajo->orden_trabajo_id])
            ->with('success', 'Trabajo actualizado correctamente.');
    }

    /**
     * Guarda múltiples trabajos de una vez (submit del formulario batch).
     */
    public function storeMultiples(Request $request)
    {
        $request->validate([
            'orden_trabajo_id'             => 'required|exists:orden_trabajos,id',
            'trabajos'                     => 'required|array|min:1',
            'trabajos.*.producto_id'       => 'required|exists:productos,id',
            'trabajos.*.ancho'             => 'required|numeric|min:0.01',
            'trabajos.*.alto'              => 'required|numeric|min:0.01',
            'trabajos.*.cantidad'          => 'required|integer|min:1',
            'trabajos.*.descripcion'       => 'nullable|string',
        ]);

        $orden = OrdenTrabajo::with('cliente.listaPrecio')->findOrFail($request->orden_trabajo_id);
        $multiplicador = $orden->cliente->listaPrecio->multiplicador ?? 1;

        foreach ($request->trabajos as $item) {
            $producto        = Producto::findOrFail($item['producto_id']);
            $precio_unitario = round($producto->precio * $multiplicador, 2);

            Trabajo::create([
                'orden_trabajo_id' => $orden->id,
                'producto_id'      => $producto->id,
                'tipo'             => $producto->tipo,
                'descripcion'      => $item['descripcion'] ?? null,
                'ancho'            => $item['ancho'],
                'alto'             => $item['alto'],
                'cantidad'         => $item['cantidad'],
                'precio_unitario'  => $precio_unitario,
                'estado'           => 'pendiente',
            ]);
        }

        return redirect()->route('ordenes-trabajo.index')->with('success', 'Trabajos guardados correctamente.');
    }

    /**
     * Guarda un trabajo vía AJAX (desde el formulario dinámico).
     */
    public function ajaxStore(Request $request)
    {
        $request->validate([
            'orden_trabajo_id' => 'required|exists:orden_trabajos,id',
            'producto_id'      => 'required|exists:productos,id',
            'ancho'            => 'required|numeric|min:0.01',
            'alto'             => 'required|numeric|min:0.01',
            'cantidad'         => 'required|integer|min:1',
            'descripcion'      => 'nullable|string',
        ]);

        $orden    = OrdenTrabajo::with('cliente.listaPrecio')->findOrFail($request->orden_trabajo_id);
        $producto = Producto::findOrFail($request->producto_id);

        $multiplicador   = $orden->cliente->listaPrecio->multiplicador ?? 1;
        $precio_unitario = round($producto->precio * $multiplicador, 2);

        $trabajo = Trabajo::create([
            'orden_trabajo_id' => $orden->id,
            'producto_id'      => $producto->id,
            'tipo'             => $producto->tipo,
            'descripcion'      => $request->descripcion,
            'ancho'            => $request->ancho,
            'alto'             => $request->alto,
            'cantidad'         => $request->cantidad,
            'precio_unitario'  => $precio_unitario,
            'estado'           => 'pendiente',
        ]);

        return response()->json([
            'success' => true,
            'trabajo' => $trabajo,
        ]);
    }

    /**
     * Elimina un trabajo.
     */
    public function destroy($id)
    {
        $trabajo = Trabajo::findOrFail($id);
        $ordenId = $trabajo->orden_trabajo_id;
        $trabajo->delete();

        return redirect()->route('ordenes.trabajos', ['orden' => $ordenId])
            ->with('success', 'Trabajo eliminado.');
    }

    /**
     * Marca un trabajo como terminado vía AJAX.
     */
    public function marcarTerminado($id)
    {
        $trabajo         = Trabajo::findOrFail($id);
        $trabajo->estado = 'terminado';
        $trabajo->save();

        return response()->json(['success' => true]);
    }
}
