<?php

namespace App\Http\Controllers;

use App\Models\OrdenTrabajo;
use App\Models\Trabajo;

class DashboardController extends Controller
{
    public function index()
    {
        // Contadores por estado de orden
        $contadores = [
            'borrador'      => OrdenTrabajo::where('activo', 1)->where('estado', 'borrador')->count(),
            'en_produccion' => OrdenTrabajo::where('activo', 1)->where('estado', 'en_produccion')->count(),
            'lista'         => OrdenTrabajo::where('activo', 1)->where('estado', 'lista')->count(),
            'entregada'     => OrdenTrabajo::where('activo', 1)->where('estado', 'entregada')->count(),
        ];

        // Órdenes activas (borrador + en producción) con sus trabajos para el listado
        $ordenes = OrdenTrabajo::with(['cliente', 'trabajos'])
            ->where('activo', 1)
            ->whereIn('estado', ['borrador', 'en_produccion', 'lista'])
            ->orderByRaw("CASE estado
                WHEN 'en_produccion' THEN 1
                WHEN 'lista'         THEN 2
                WHEN 'borrador'      THEN 3
                ELSE 4 END")
            ->orderByDesc('id')
            ->get();

        return view('dashboard', compact('contadores', 'ordenes'));
    }
}
