

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Órdenes de Trabajo</h1>
    <a href="<?php echo e(route('ordenes-trabajo.create')); ?>" class="btn btn-success mb-3">
    + Crear nueva orden
</a>


    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($ordenes->isEmpty()): ?>
        <div class="alert alert-warning text-center">
            No hay órdenes de trabajo registradas.
        </div>
    <?php else: ?>
        <div class="list-group">
            <?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $total = $orden->trabajos->count();
                    $terminados = $orden->trabajos->where('estado', 'terminado')->count();
                    $porcentaje = ($total > 0) ? ($terminados / $total * 100) : 0;
                ?>
                <div class="list-group-item mb-2 shadow-sm">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="mb-1">Orden #<?php echo e($orden->id); ?> — <?php echo e($orden->cliente->nombre ?? 'Sin cliente'); ?></h5>
                            <p class="mb-1">
                                <strong>Fecha:</strong> <?php echo e($orden->fecha_recibido); ?> <br>
                                <strong>Observaciones:</strong> <?php echo e($orden->observaciones ?? '-'); ?>

                            </p>
                            <div class="progress" style="height: 20px;">
                                <div class="progress-bar bg-success" role="progressbar"
                                    style="width: <?php echo e($porcentaje); ?>%;" aria-valuenow="<?php echo e($porcentaje); ?>"
                                    aria-valuemin="0" aria-valuemax="100">
                                    <?php echo e(round($porcentaje, 2)); ?>%
                                </div>
                            </div>
                        </div>
                        <div class="text-end">
                        <a href="<?php echo e(route('ordenes-trabajo.show', $orden->id)); ?>" class="btn btn-info btn-sm mb-1">Ver</a>
                            <a href="<?php echo e(route('ordenes-trabajo.edit', $orden->id)); ?>" class="btn btn-primary btn-sm mb-1">Editar</a>
                            <form action="<?php echo e(route('ordenes-trabajo.destroy', $orden->id)); ?>" method="POST" style="display:inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm"
                                    onclick="return confirm('¿Estás seguro de eliminar esta orden?')">
                                    Eliminar
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\grafica-app\resources\views/ordenes/index.blade.php ENDPATH**/ ?>