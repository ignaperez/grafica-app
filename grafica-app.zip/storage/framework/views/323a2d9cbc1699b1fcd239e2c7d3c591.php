

<?php $__env->startSection('content'); ?>
    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    
    <style>
        .select2-container { width: 100% !important; }
        .select2-container .select2-selection--single {
            height: 38px !important;
            display: flex !important;
            align-items: center !important;
        }
        .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 38px !important;
        }
        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 38px !important;
        }
    </style>

    <div class="container">
        <h2 class="mb-4">Agregar trabajos a la Orden #<?php echo e($orden->id); ?></h2>

        <div id="alerta-exito" style="display:none;"
             class="bg-green-100 border border-green-400 text-green-700 px-4 py-2 rounded mb-4">
            Trabajo agregado correctamente.
        </div>

        
        <form id="trabajo-form" method="POST" action="<?php echo e(route('trabajos.store-multiples')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" id="orden_trabajo_id" name="orden_trabajo_id" value="<?php echo e($orden->id); ?>">

            <div id="contenedor-trabajos"></div>

            <button type="button" id="btn-agregar-fila" class="btn btn-outline-primary mb-3">
                + Agregar trabajo
            </button>

            <button type="submit" class="btn btn-success">
                Guardar todos
            </button>

            <a href="<?php echo e(route('ordenes-trabajo.index')); ?>" class="btn btn-secondary">Volver</a>
        </form>

        <hr>

        <h4 class="mt-4">Trabajos cargados</h4>
        <div id="trabajos-lista" class="mt-3"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script>
        let index = 0;

        function crearFilaTrabajo(i) {
            return `
                <div class="row mb-3 trabajo-fila border p-3 rounded">
                    <div class="col-md-3">
                        <label>Producto *</label>
                        <select name="trabajos[${i}][producto_id]"
                                class="form-control select2-producto"
                                style="width:100%"
                                required>
                            <option value="">Seleccione producto</option>
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($producto->id); ?>"><?php echo e($producto->nombre); ?> — <?php echo e($producto->tipo); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label>Tipo *</label>
                        <input type="text" name="trabajos[${i}][tipo]" class="form-control" required>
                    </div>

                    <div class="col-md-2">
                        <label>Ancho (m)</label>
                        <input type="number" step="0.01" name="trabajos[${i}][ancho]" class="form-control ancho">
                    </div>

                    <div class="col-md-2">
                        <label>Alto (m)</label>
                        <input type="number" step="0.01" name="trabajos[${i}][alto]" class="form-control alto">
                    </div>

                    <div class="col-md-1">
                        <label>Cant.</label>
                        <input type="number" name="trabajos[${i}][cantidad]" class="form-control cantidad" value="1" min="1">
                    </div>

                    <div class="col-md-1">
                        <label>m²</label>
                        <input type="text" class="form-control consumo" readonly>
                    </div>

                    <div class="col-md-11 mt-2">
                        <label>Observaciones</label>
                        <textarea name="trabajos[${i}][observaciones]" class="form-control" rows="1"></textarea>
                    </div>

                    <div class="col-md-1 mt-4 d-flex align-items-end">
                        <button type="button" class="btn btn-danger btn-sm eliminar-fila">X</button>
                    </div>
                </div>
            `;
        }

        // Inicializa Select2 SOLO dentro de un scope (la fila nueva)
        function initSelect2En($scope) {
            $scope.find('select.select2-producto').each(function () {
                const $el = $(this);
                if ($el.hasClass('select2-hidden-accessible')) return;

                $el.select2({
                    width: 'resolve',
                    dropdownAutoWidth: true,
                    placeholder: 'Seleccione producto'
                });
            });
        }

        function calcularConsumoFila($fila) {
            const ancho = parseFloat($fila.find('.ancho').val()) || 0;
            const alto = parseFloat($fila.find('.alto').val()) || 0;
            const cantidad = parseInt($fila.find('.cantidad').val()) || 0;

            if (ancho > 0 && alto > 0 && cantidad > 0) {
                $fila.find('.consumo').val((ancho * alto * cantidad).toFixed(2));
            } else {
                $fila.find('.consumo').val('');
            }
        }

        // Cargar trabajos existentes (usa tu ruta existente trabajos/ajax-list/{ordenTrabajo})
        function cargarTrabajos() {
            const ordenId = $('#orden_trabajo_id').val();

            $.get("<?php echo e(url('trabajos/ajax-list')); ?>/" + ordenId)
                .done(function (html) {
                    $('#trabajos-lista').html(html);
                })
                .fail(function (xhr) {
                    console.error('Error cargando trabajos:', xhr.status, xhr.responseText);
                    $('#trabajos-lista').html(
                        `<div class="alert alert-danger">No se pudieron cargar los trabajos (HTTP ${xhr.status}).</div>`
                    );
                });
        }

        $(document).ready(function () {

            // Agregar fila
            $('#btn-agregar-fila').on('click', function () {
                $('#contenedor-trabajos').append(crearFilaTrabajo(index));

                const $ultimaFila = $('#contenedor-trabajos .trabajo-fila').last();
                initSelect2En($ultimaFila);

                index++;
            });

            // Eliminar fila
            $('#contenedor-trabajos').on('click', '.eliminar-fila', function () {
                $(this).closest('.trabajo-fila').remove();
            });

            // Recalcular m²
            $('#contenedor-trabajos').on('input', '.ancho, .alto, .cantidad', function () {
                calcularConsumoFila($(this).closest('.trabajo-fila'));
            });

            // Validación submit
            $('#trabajo-form').on('submit', function (e) {
                if ($('.trabajo-fila').length === 0) {
                    e.preventDefault();
                    alert('Debe agregar al menos un trabajo antes de guardar.');
                }
            });

            // Cargar trabajos existentes
            cargarTrabajos();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\grafica-app\resources\views/ordenes-trabajo/trabajos.blade.php ENDPATH**/ ?>