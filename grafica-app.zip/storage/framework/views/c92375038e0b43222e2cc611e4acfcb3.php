

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Orden de Trabajo #<?php echo e($orden_trabajo->id); ?></h2>
    
    <div class="card mb-4">
        <div class="card-body">
            <p><strong>Cliente:</strong> <?php echo e($orden_trabajo->cliente->nombre ?? 'Sin cliente'); ?></p>
            <p><strong>Fecha de recepción:</strong> <?php echo e($orden_trabajo->fecha_recibido ? \Carbon\Carbon::parse($orden_trabajo->fecha_recibido)->format('d/m/Y') : '-'); ?></p>
            <p><strong>Estado:</strong> <?php echo e(ucfirst($orden_trabajo->estado)); ?></p>
            <p><strong>Observaciones:</strong> <?php echo e($orden_trabajo->observaciones ?? '-'); ?></p>
            <?php if($orden_trabajo->fotos->count() > 0): ?>
    <div>
        <label>Fotos:</label>
        <div class="d-flex flex-wrap gap-2">
            <?php $__currentLoopData = $orden_trabajo->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e(asset('storage/' . $foto->ruta)); ?>" alt="Foto" width="200">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>
        </div>
    </div>
    <h4>Trabajos Asociados</h4>

<?php if($orden_trabajo->trabajos->count()): ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Producto</th>
                <th>Ancho (m)</th>
                <th>Alto (m)</th>
                <th>Cantidad</th>
                <th>Descripcion</th>
                <th>Consumo (m²)</th>
            </tr>
        </thead>
        <tbody>
        
            <?php $__currentLoopData = $orden_trabajo->trabajos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($trabajo->producto->nombre ?? $trabajo->tipo); ?></td>
                    <td><?php echo e($trabajo->ancho ?? '-'); ?></td>
                    <td><?php echo e($trabajo->alto ?? '-'); ?></td>
                    <td><?php echo e($trabajo->cantidad); ?></td>
                    <td><?php echo e($trabajo->descripcion ?? '-'); ?></td>
                    <td>
                    <?php
                                $consumo = 0;
                                if ($trabajo->ancho && $trabajo->alto) {
                                    $consumo = round($trabajo->ancho * $trabajo->alto * $trabajo->cantidad, 2);
                                }
                         
                        ?>
                        <?php echo e($consumo); ?> m²
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No hay trabajos registrados.</p>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\grafica-app\resources\views/ordenes-trabajo/show.blade.php ENDPATH**/ ?>