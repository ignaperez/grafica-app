

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-4">
    <h1 class="text-2xl font-bold mb-4">Fichadas</h1>

    <?php if(session('ok')): ?>
        <div class="mb-3 p-3 rounded bg-green-100 text-green-800">
            <?php echo e(session('ok')); ?>

        </div>
    <?php endif; ?>

    
    <form method="GET"
          action="<?php echo e(route('rrhh.fichadas.index')); ?>"
          class="grid grid-cols-1 md:grid-cols-4 gap-3 mb-4">

        <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Empleado
            </label>
            <select name="empleado_id"
                    class="w-full rounded border-gray-300 dark:border-gray-600 dark:bg-gray-900 dark:text-gray-100 text-sm">
                <option value="">Todos</option>
                <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($e->id); ?>"
                        <?php if(request('empleado_id') == $e->id): echo 'selected'; endif; ?>
                    >
                        <?php echo e($e->nombre_completo); ?> (<?php echo e($e->codigo); ?>)
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Desde
            </label>
            <input type="date"
                   name="desde"
                   value="<?php echo e(request('desde')); ?>"
                   class="w-full rounded border-gray-300 dark:border-gray-600 dark:bg-gray-900 dark:text-gray-100 text-sm">
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Hasta
            </label>
            <input type="date"
                   name="hasta"
                   value="<?php echo e(request('hasta')); ?>"
                   class="w-full rounded border-gray-300 dark:border-gray-600 dark:bg-gray-900 dark:text-gray-100 text-sm">
        </div>

        <div class="flex items-end gap-2">
            <button type="submit"
                    class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 focus:outline-none">
                Filtrar
            </button>

            <a href="<?php echo e(route('rrhh.fichadas.index')); ?>"
               class="inline-flex items-center px-3 py-2 border border-gray-300 rounded-md text-xs text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800">
                Limpiar
            </a>
        </div>
    </form>

    
    <div class="overflow-x-auto bg-white dark:bg-gray-900 shadow-sm rounded-lg">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 text-sm">
            <thead class="bg-gray-50 dark:bg-gray-800">
                <tr>
                    <th class="px-3 py-2 text-left font-medium text-gray-700 dark:text-gray-300">Fecha</th>
                    <th class="px-3 py-2 text-left font-medium text-gray-700 dark:text-gray-300">Hora</th>
                    <th class="px-3 py-2 text-left font-medium text-gray-700 dark:text-gray-300">Empleado</th>
                    <th class="px-3 py-2 text-left font-medium text-gray-700 dark:text-gray-300">Tipo</th>
                    <th class="px-3 py-2 text-left font-medium text-gray-700 dark:text-gray-300">Origen</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                <?php $__empty_1 = true; $__currentLoopData = $fichadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-3 py-2 whitespace-nowrap">
                            <?php echo e($f->momento->format('d/m/Y')); ?>

                        </td>
                        <td class="px-3 py-2 whitespace-nowrap">
                            <?php echo e($f->momento->format('H:i')); ?>

                        </td>
                        <td class="px-3 py-2">
                          <?php echo e($f->empleado?->nombre_completo ?? 'Empleado no encontrado'); ?><br>
                            <span class="text-xs text-gray-500">(<?php echo e($f->empleado?->codigo ?? ('#' . $f->empleado_id)); ?>

)</span>
                        </td>
                        <td class="px-3 py-2 uppercase">
                            <?php echo e($f->tipo); ?>

                        </td>
                        <td class="px-3 py-2">
                            <?php echo e($f->origen ?? '-'); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-3 py-4 text-center text-gray-500">
                            No hay fichadas para los filtros seleccionados.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-3">
        <?php echo e($fichadas->withQueryString()->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\grafica-app\resources\views/rrhh/fichadas/index.blade.php ENDPATH**/ ?>