

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Nuevo Cliente</h1>

    <form action="<?php echo e(route('clientes.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="nombre" class="form-label">Nombre *</label>
            <input type="text" name="nombre" class="form-control" required value="<?php echo e(old('nombre')); ?>">
        </div>

        <div class="mb-3">
            <label for="telefono" class="form-label">Teléfono</label>
            <input type="text" name="telefono" class="form-control" value="<?php echo e(old('telefono')); ?>">
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>">
        </div>

        <div class="mb-3">
            <label for="direccion" class="form-label">Dirección</label>
            <textarea name="direccion" class="form-control"><?php echo e(old('direccion')); ?></textarea>
        </div>

        <div class="mb-3">
            <label for="lista_precio_id" class="form-label">Lista de Precios</label>
            <select name="lista_precio_id" id="lista_precio_id" class="form-select" required style="width: 100%">
            <?php $__currentLoopData = $listas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($lista->id); ?>" <?php echo e(old('lista_precio_id', 1) == $lista->id ? 'selected' : ''); ?>>
                        <?php echo e($lista->nombre); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Guardar Cliente</button>
    </form>
</div>
<script>
$(document).ready(function() {
    $('#lista_precio_id').select2({
        placeholder: 'Seleccionar lista de precios',
        allowClear: true,
        ajax: {
            url: '/listas-precios/buscar',
            dataType: 'json',
            delay: 250,
            processResults: function (data) {
                return { results: data };
            },
            cache: true
        }
    });

    // Si querés que venga preseleccionado por defecto con "Consumidor Final" (id = 1)
    $('#lista_precio_id').append(new Option('Consumidor Final', 1, true, true)).trigger('change');
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\grafica-app\resources\views/clientes/create.blade.php ENDPATH**/ ?>