

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Listado de Productos</h2>

    <a href="<?php echo e(route('productos.create')); ?>" class="btn btn-primary mb-3">Nuevo Producto</a>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($producto->nombre); ?></td>
                    <td><?php echo e($producto->descripcion); ?></td>
                    <td>
                        <a href="<?php echo e(route('productos.edit', $producto->id)); ?>" class="btn btn-sm btn-warning">Editar</a>
                        
                        <form action="<?php echo e(route('productos.destroy', $producto->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('¿Estás seguro de eliminar este producto?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\grafica-app\resources\views/productos/index.blade.php ENDPATH**/ ?>