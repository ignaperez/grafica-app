<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Gráfica')); ?></title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        :root{
            --bg:#0f0f0f;--bg-s:#141414;--bg-h:#1a1a1a;
            --b:#1e1e1e;--bm:#2a2a2a;
            --tx:#e8e4dc;--txm:#555;--txd:#888;
            --ac:#e6502a;
            --mono:'DM Mono',monospace;--sans:'DM Sans',sans-serif;
            --sw:220px;
        }
        html,body{height:100%;background:var(--bg);color:var(--tx);font-family:var(--sans);font-size:14px;line-height:1.6}

        /* SIDEBAR */
        #sidebar{position:fixed;top:0;left:0;bottom:0;width:var(--sw);background:var(--bg-s);border-right:1px solid var(--b);display:flex;flex-direction:column;z-index:100;transition:transform .2s}
        .s-logo{padding:22px 20px 16px;border-bottom:1px solid var(--b)}
        .s-mark{font-family:var(--mono);font-size:10px;letter-spacing:3px;text-transform:uppercase;color:var(--ac);margin-bottom:3px}
        .s-name{font-size:15px;font-weight:500;color:var(--tx);letter-spacing:-.3px}
        .s-nav{flex:1;padding:12px 10px;overflow-y:auto}
        .s-section{font-size:10px;letter-spacing:2px;text-transform:uppercase;color:#333;padding:10px 10px 5px}
        .s-item{display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:7px;font-size:13.5px;color:var(--txd);text-decoration:none;transition:all .12s;margin-bottom:1px}
        .s-item:hover{background:var(--bg-h);color:var(--tx);text-decoration:none}
        .s-item.on{background:#1c1c1c;color:var(--tx)}
        .s-item.on .dot{background:var(--ac)}
        .dot{width:5px;height:5px;border-radius:50%;background:#2a2a2a;flex-shrink:0;transition:background .12s}
        .s-trigger{display:flex;align-items:center;justify-content:space-between;width:100%;padding:8px 10px;border-radius:7px;font-size:13.5px;color:var(--txd);background:none;border:none;cursor:pointer;font-family:var(--sans);transition:all .12s;margin-bottom:1px}
        .s-trigger:hover{background:var(--bg-h);color:var(--tx)}
        .s-trigger .tl{display:flex;align-items:center;gap:10px}
        .s-arrow{font-size:10px;color:#333;transition:transform .15s}
        .s-trigger.open .s-arrow{transform:rotate(90deg)}
        .s-sub{display:none;padding-left:20px}
        .s-sub.open{display:block}
        .s-user{padding:14px 18px;border-top:1px solid var(--b);display:flex;align-items:center;gap:10px}
        .s-avatar{width:30px;height:30px;border-radius:50%;background:#1e100a;border:1px solid #3a1e10;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:500;color:var(--ac);flex-shrink:0}
        .s-uname{font-size:13px;font-weight:500;color:var(--tx)}
        .s-logout{font-size:11px;color:#3a3a3a;background:none;border:none;cursor:pointer;font-family:var(--sans);padding:0;transition:color .12s;text-align:left}
        .s-logout:hover{color:var(--ac)}

        /* MAIN */
        #main{margin-left:var(--sw);min-height:100vh;display:flex;flex-direction:column}
        .topbar{height:54px;border-bottom:1px solid var(--b);display:flex;align-items:center;justify-content:space-between;padding:0 28px;background:var(--bg);position:sticky;top:0;z-index:50}
        .topbar-bc{font-size:13px;color:var(--txm);display:flex;align-items:center;gap:8px}
        .topbar-bc span{color:#333}
        .topbar-bc strong{color:var(--tx);font-weight:500}
        .page-content{flex:1;padding:28px 28px 48px}

        /* FLASH */
        .flash{margin-bottom:18px;padding:11px 16px;border-radius:8px;font-size:13px;display:flex;align-items:center;gap:8px}
        .flash-ok{background:#0a1f0d;border:1px solid #1a3d20;color:#4caf6e}
        .flash-err{background:#1f0a0a;border:1px solid #3d1a1a;color:#e05555}

        /* CARDS */
        .gcard{background:var(--bg-s);border:1px solid var(--b);border-radius:12px;overflow:hidden}
        .gcard-hd{padding:14px 20px;border-bottom:1px solid var(--b);display:flex;align-items:center;justify-content:space-between}
        .gcard-title{font-size:13px;font-weight:500;color:var(--tx)}
        .gcard-bd{padding:20px}

        /* BUTTONS */
        .gbtn{display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:7px;font-size:13px;font-weight:500;font-family:var(--sans);cursor:pointer;text-decoration:none;transition:all .12s;border:none;line-height:1}
        .gbtn-primary{background:var(--ac);color:#fff}
        .gbtn-primary:hover{background:#cc4424;color:#fff;text-decoration:none}
        .gbtn-ghost{background:transparent;color:var(--txd);border:1px solid var(--bm)}
        .gbtn-ghost:hover{background:var(--bg-h);color:var(--tx);border-color:#3a3a3a;text-decoration:none}
        .gbtn-danger{background:#1f0a0a;color:#e05555;border:1px solid #3d1a1a}
        .gbtn-danger:hover{background:#2a0e0e;color:#ef6666;text-decoration:none}
        .gbtn-sm{padding:5px 11px;font-size:12px}
        .gbtn-xs{padding:3px 9px;font-size:11px}

        /* BADGES */
        .badge-estado{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:500;white-space:nowrap}
        .badge-estado::before{content:'';width:5px;height:5px;border-radius:50%;flex-shrink:0}
        .be-borrador{background:#1a1a1a;color:#666}.be-borrador::before{background:#444}
        .be-en_produccion{background:#1f1800;color:#d4900a}.be-en_produccion::before{background:#d4900a}
        .be-lista{background:#0d1f10;color:#4caf6e}.be-lista::before{background:#4caf6e}
        .be-entregada{background:#0d1520;color:#4a8fd4}.be-entregada::before{background:#4a8fd4}
        .be-cancelada{background:#1f0a0a;color:#e05555}.be-cancelada::before{background:#e05555}
        .be-pendiente{background:#1a1a1a;color:#666}.be-pendiente::before{background:#444}
        .be-en_proceso{background:#1f1800;color:#d4900a}.be-en_proceso::before{background:#d4900a}
        .be-terminado{background:#0d1f10;color:#4caf6e}.be-terminado::before{background:#4caf6e}
        .be-entregado{background:#0d1520;color:#4a8fd4}.be-entregado::before{background:#4a8fd4}

        /* TABLES */
        .gtable{width:100%;border-collapse:collapse}
        .gtable th{font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:#444;font-weight:400;padding:10px 16px;border-bottom:1px solid var(--b);text-align:left}
        .gtable td{padding:13px 16px;border-bottom:1px solid #181818;font-size:13.5px;color:var(--tx);vertical-align:middle}
        .gtable tr:last-child td{border-bottom:none}
        .gtable tbody tr{transition:background .1s}
        .gtable tbody tr:hover{background:#181818}

        /* FORMS */
        .gfg{margin-bottom:18px}
        .glabel{display:block;font-size:10px;letter-spacing:1px;text-transform:uppercase;color:var(--txm);margin-bottom:6px}
        .ginput,.gselect,.gtextarea{width:100%;background:#0a0a0a;border:1px solid var(--bm);border-radius:7px;padding:9px 12px;font-size:13.5px;color:var(--tx);font-family:var(--sans);transition:border-color .12s;outline:none}
        .ginput:focus,.gselect:focus,.gtextarea:focus{border-color:var(--ac)}
        .ginput::placeholder{color:#333}
        .gtextarea{resize:vertical;min-height:80px}
        .gerr{font-size:12px;color:#e05555;margin-top:4px}

        /* PROGRESS */
        .gprog{height:3px;background:#232323;border-radius:2px;overflow:hidden}
        .gprog-fill{height:100%;border-radius:2px;background:var(--ac)}
        .gprog-fill.done{background:#4caf6e}

        /* MISC */
        .mono{font-family:var(--mono)}
        .txm{color:var(--txm)}
        .txd{color:var(--txd)}

        /* Select2 dark */
        .select2-container--default .select2-selection--single{background:#0a0a0a;border:1px solid var(--bm);border-radius:7px;height:38px;display:flex;align-items:center}
        .select2-container--default .select2-selection--single .select2-selection__rendered{color:var(--tx);line-height:38px;padding-left:12px}
        .select2-container--default .select2-selection--single .select2-selection__arrow{height:36px}
        .select2-dropdown{background:#141414;border:1px solid var(--bm);border-radius:7px}
        .select2-container--default .select2-results__option{color:var(--txd);font-size:13.5px}
        .select2-container--default .select2-results__option--highlighted{background:var(--bg-h);color:var(--tx)}
        .select2-search--dropdown .select2-search__field{background:#0a0a0a;border:1px solid var(--bm);color:var(--tx);border-radius:5px;padding:6px 10px}

        /* Mobile */
        .s-toggle{display:none;background:none;border:none;color:var(--tx);cursor:pointer;font-size:20px;line-height:1}
        @media(max-width:768px){
            #sidebar{transform:translateX(-100%)}
            #sidebar.open{transform:translateX(0)}
            #main{margin-left:0}
            .s-toggle{display:block}
            .page-content{padding:18px 16px 36px}
        }
    </style>
</head>
<body>

<aside id="sidebar">
    <div class="s-logo">
        <div class="s-mark">GFX</div>
        <div class="s-name"><?php echo e(config('app.name', 'Gráfica')); ?></div>
    </div>
    <nav class="s-nav">
        <div class="s-section">Producción</div>
        <a href="<?php echo e(route('dashboard')); ?>" class="s-item <?php echo e(request()->routeIs('dashboard') ? 'on' : ''); ?>">
            <span class="dot"></span> Dashboard
        </a>
        <a href="<?php echo e(route('ordenes-trabajo.index')); ?>" class="s-item <?php echo e(request()->routeIs('ordenes-trabajo.*') ? 'on' : ''); ?>">
            <span class="dot"></span> Órdenes de trabajo
        </a>
        <a href="<?php echo e(route('clientes.index')); ?>" class="s-item <?php echo e(request()->routeIs('clientes.*') ? 'on' : ''); ?>">
            <span class="dot"></span> Clientes
        </a>
        <?php if(auth()->user()->rol === 'admin'): ?>
            <div class="s-section">Catálogo</div>
            <a href="<?php echo e(route('productos.index')); ?>" class="s-item <?php echo e(request()->routeIs('productos.*') ? 'on' : ''); ?>">
                <span class="dot"></span> Productos
            </a>
            <a href="<?php echo e(route('listas-precios.index')); ?>" class="s-item <?php echo e(request()->routeIs('listas-precios.*') ? 'on' : ''); ?>">
                <span class="dot"></span> Listas de precios
            </a>
            <div class="s-section">RRHH</div>
            <button class="s-trigger <?php echo e(request()->is('rrhh/*') ? 'open' : ''); ?>" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open')">
                <span class="tl"><span class="dot" style="<?php echo e(request()->is('rrhh/*') ? 'background:var(--ac)' : ''); ?>"></span> RRHH</span>
                <span class="s-arrow">›</span>
            </button>
            <div class="s-sub <?php echo e(request()->is('rrhh/*') ? 'open' : ''); ?>">
                <a href="<?php echo e(route('rrhh.dashboard')); ?>" class="s-item <?php echo e(request()->routeIs('rrhh.dashboard') ? 'on' : ''); ?>"><span class="dot"></span> Panel</a>
                <a href="<?php echo e(route('rrhh.empleados.index')); ?>" class="s-item <?php echo e(request()->routeIs('rrhh.empleados.*') ? 'on' : ''); ?>"><span class="dot"></span> Empleados</a>
                <a href="<?php echo e(route('rrhh.fichadas.index')); ?>" class="s-item <?php echo e(request()->routeIs('rrhh.fichadas.*') ? 'on' : ''); ?>"><span class="dot"></span> Fichadas</a>
                <a href="<?php echo e(route('fichar.form')); ?>" target="_blank" class="s-item"><span class="dot"></span> Reloj tablet ↗</a>
            </div>
        <?php endif; ?>
    </nav>
    <div class="s-user">
        <div class="s-avatar"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 2))); ?></div>
        <div>
            <div class="s-uname"><?php echo e(auth()->user()->name); ?></div>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="s-logout">Cerrar sesión</button>
            </form>
        </div>
    </div>
</aside>

<div id="main">
    <div class="topbar">
        <div style="display:flex;align-items:center;gap:12px">
            <button class="s-toggle" onclick="document.getElementById('sidebar').classList.toggle('open')">☰</button>
            <div class="topbar-bc">
                <span><?php echo e(config('app.name')); ?></span>
                <span>›</span>
                <strong><?php echo $__env->yieldContent('page-title', 'Dashboard'); ?></strong>
            </div>
        </div>
        <div><?php echo $__env->yieldContent('topbar-actions'); ?></div>
    </div>

    <div class="page-content">
        <?php if(session('success')): ?>
            <div class="flash flash-ok">✓ &nbsp;<?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('ok')): ?>
            <div class="flash flash-ok">✓ &nbsp;<?php echo e(session('ok')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="flash flash-err">✕ &nbsp;<?php echo e(session('error')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="flash flash-err">
                <div>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>✕ &nbsp;<?php echo e($e); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\grafica-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>