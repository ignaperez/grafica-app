

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-4">
    <h1 class="text-2xl font-bold mb-4">Empleados</h1>

    <?php if(session('ok')): ?>
        <div class="mb-3 p-3 rounded bg-green-100 text-green-800">
            <?php echo e(session('ok')); ?>

        </div>
    <?php endif; ?>

    <div class="mb-3">
        <a href="<?php echo e(route('rrhh.empleados.create')); ?>"
           class="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-xs font-semibold rounded-md hover:bg-blue-700">
            Nuevo empleado
        </a>
    </div>

    <div class="overflow-x-auto bg-white dark:bg-gray-900 shadow-sm rounded-lg">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 text-sm">
            <thead class="bg-gray-50 dark:bg-gray-800">
                <tr>
                    <th class="px-3 py-2 text-left">Nombre</th>
                    <th class="px-3 py-2 text-left">Código</th>
                    <th class="px-3 py-2 text-left">Activo</th>
                    <th class="px-3 py-2 text-left">Acciones</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                <?php $__empty_1 = true; $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-3 py-2">
                            <?php echo e($empleado->nombre_completo); ?>

                        </td>
                        <td class="px-3 py-2">
                            <?php echo e($empleado->codigo); ?>

                        </td>
                        <td class="px-3 py-2">
                            <?php if($empleado->activo): ?>
                                <span class="px-2 py-1 text-xs rounded bg-green-100 text-green-800">Sí</span>
                            <?php else: ?>
                                <span class="px-2 py-1 text-xs rounded bg-gray-200 text-gray-700">No</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-3 py-2 space-x-1">
                            <a href="<?php echo e(route('rrhh.empleados.fichadas', $empleado)); ?>"
                               class="text-xs text-green-700 hover:underline">
                                Ver horas
                            </a>
                            <a href="<?php echo e(route('rrhh.empleados.edit', $empleado)); ?>"
                               class="text-xs text-blue-700 hover:underline">
                                Editar
                            </a>
                            <form action="<?php echo e(route('rrhh.empleados.destroy', $empleado)); ?>"
                                  method="POST"
                                  class="inline"
                                  onsubmit="return confirm('¿Eliminar empleado?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                        class="text-xs text-red-700 hover:underline">
                                    Borrar
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="px-3 py-4 text-center text-gray-500">
                            No hay empleados cargados.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-3">
        <?php echo e($empleados->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\grafica-app\resources\views/rrhh/empleados/index.blade.php ENDPATH**/ ?>