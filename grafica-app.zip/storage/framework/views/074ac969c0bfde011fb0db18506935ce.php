

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Nueva Orden de Trabajo</h2>

    <form action="<?php echo e(route('ordenes-trabajo.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>Cliente</label>
            <select name="cliente_id" id="cliente_id" class="form-control" required></select>
        </div>

        <div class="mb-3">
            <label>Fecha recibido</label>
            <input type="date" name="fecha_recibido" class="form-control" value="<?php echo e(date('Y-m-d')); ?>">
        </div>

        <div class="mb-3">
            <label>Observaciones</label>
            <textarea name="observaciones" class="form-control"></textarea>
        </div>

        <button class="btn btn-primary">Crear orden</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
$(function(){
    $('#cliente_id').select2({
        placeholder: 'Buscar cliente...',
        minimumInputLength: 2,
        ajax: {
            url: "<?php echo e(url('clientes/search')); ?>",
            dataType: 'json',
            delay: 250,
            data: params => ({ q: params.term }),
            processResults: data => ({ results: data })
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\grafica-app\resources\views/ordenes-trabajo/create.blade.php ENDPATH**/ ?>