

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Listas de Precios</h2>

    <a href="<?php echo e(route('listas-precios.create')); ?>" class="btn btn-primary mb-3">Nueva Lista</a>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $listas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($lista->nombre); ?></td>
                    <td><?php echo e($lista->descripcion ?? '-'); ?></td>
                    <td>
                        <a href="<?php echo e(route('listas-precios.edit', $lista->id)); ?>" class="btn btn-sm btn-warning">Editar</a>

                        <form action="<?php echo e(route('listas-precios.destroy', $lista->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('¿Eliminar esta lista?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\grafica-app\resources\views/listas-precios/index.blade.php ENDPATH**/ ?>