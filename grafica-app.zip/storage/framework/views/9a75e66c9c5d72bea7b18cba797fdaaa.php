

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>RRHH - Presentismo</h1>

    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card border-success">
                <div class="card-body">
                    <h5 class="card-title">Fichadas de hoy</h5>
                    <p class="card-text display-6"><?php echo e($totalHoy); ?></p>
                    <small class="text-muted"><?php echo e($hoy->format('d/m/Y')); ?></small>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-primary">
                <div class="card-body">
                    <h5 class="card-title">Empleados activos</h5>
                    <p class="card-text display-6"><?php echo e($empleados); ?></p>
                </div>
            </div>
        </div>
    </div>

    <a href="<?php echo e(route('rrhh.fichadas.hoy')); ?>" class="btn btn-success">Ver fichadas de hoy</a>
    <a href="<?php echo e(route('rrhh.fichadas.index')); ?>" class="btn btn-outline-secondary">Buscar fichadas</a>
    <a href="<?php echo e(route('rrhh.empleados.index')); ?>" class="btn btn-outline-primary">Empleados</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\grafica-app\resources\views/rrhh/dashboard.blade.php ENDPATH**/ ?>