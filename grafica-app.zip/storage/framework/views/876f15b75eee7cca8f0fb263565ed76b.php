

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Editar Orden de Trabajo #<?php echo e($orden->id); ?></h1>

        <div class="alert alert-info mt-2">
            Porcentaje de trabajos completados: <?php echo e(round($porcentaje, 2)); ?>%
        </div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form id="orden-form" action="<?php echo e(route('ordenes-trabajo.update', $orden->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3">
                <label>Cliente</label>
                <select name="cliente_id" id="cliente_id" class="form-control select2" required>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cli->id); ?>" <?php echo e($cli->id == $orden->cliente_id ? 'selected' : ''); ?>>
                            <?php echo e($cli->nombre); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="fecha_recibido">Fecha de recepción</label>
                <input type="date" name="fecha_recibido" id="fecha_recibido" class="form-control" required
                    value="<?php echo e(old('fecha_recibido', $orden->fecha_recibido)); ?>">
            </div>

            <div class="mb-3">
                <label for="observaciones">Observaciones</label>
                <textarea name="observaciones" id="observaciones"
                    class="form-control"><?php echo e(old('observaciones', $orden->observaciones)); ?></textarea>
            </div>

            <hr>
            <h4>Trabajos</h4>

            <div id="trabajos-container">
                <?php $__currentLoopData = $orden->trabajos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $trabajo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="trabajo border p-3 mb-3" data-trabajo-id="<?php echo e($trabajo->id); ?>">
                        <input type="hidden" name="trabajos[<?php echo e($index); ?>][id]" value="<?php echo e($trabajo->id); ?>">


                        <div class="mb-2">
                            <label>Producto</label>
                            <select name="trabajos[<?php echo e($index); ?>][producto_id]" class="form-control select2-producto" required>
                                <option value="">Seleccione producto</option>
                                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($producto->id); ?>" <?php echo e($producto->id == $trabajo->producto_id ? 'selected' : ''); ?>>
                                        <?php echo e($producto->nombre); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-2">
                            <label>Tipo de trabajo</label>
                            <input type="text" name="trabajos[<?php echo e($index); ?>][tipo]" class="form-control" required
                                value="<?php echo e($trabajo->tipo); ?>">
                        </div>
                        <div class="mb-2">
                            <label>Descripción</label>
                            <input type="text" name="trabajos[<?php echo e($index); ?>][descripcion]" class="form-control"
                                value="<?php echo e($trabajo->descripcion); ?>">
                        </div>
                        <div class="row mb-2">
                            <div class="col">
                                <label>Ancho (cm)</label>
                                <input type="number" step="0.01" name="trabajos[<?php echo e($index); ?>][ancho]" class="form-control"
                                    value="<?php echo e($trabajo->ancho); ?>">
                            </div>
                            <div class="col">
                                <label>Alto (cm)</label>
                                <input type="number" step="0.01" name="trabajos[<?php echo e($index); ?>][alto]" class="form-control"
                                    value="<?php echo e($trabajo->alto); ?>">
                            </div>
                        </div>
                        <div class="mb-2">
                            <label>Cantidad</label>
                            <input type="number" name="trabajos[<?php echo e($index); ?>][cantidad]" class="form-control"
                                value="<?php echo e($trabajo->cantidad); ?>">
                        </div>
                        <div class="mb-2">
                            <label>Fecha de entrega</label>
                            <input type="date" name="trabajos[<?php echo e($index); ?>][fecha_entrega]" class="form-control"
                                value="<?php echo e($trabajo->fecha_entrega); ?>">
                        </div>
                        <div class="mb-2">
                            <label>Estado:</label>
                            <span class="badge <?php echo e($trabajo->estado == 'terminado' ? 'bg-success' : 'bg-secondary'); ?>">
                                <?php echo e($trabajo->estado); ?>

                            </span>
                            <button type="button" class="btn btn-sm btn-success marcar-terminado ms-2">Marcar como
                                Terminado</button>
                            <button type="button" class="btn btn-danger btn-sm eliminar-trabajo ms-2">Eliminar</button>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <button type="button" id="agregar-trabajo" class="btn btn-secondary mb-3">+ Agregar otro trabajo</button>

            <button type="submit" class="btn btn-primary">Actualizar Orden</button>
        </form>

        <hr>
        <h4>Previsualización de Trabajos</h4>
        <div id="preview-container"></div>
    </div>

    <script>
        let index = <?php echo e(count($orden->trabajos)); ?>;
        let productosOptions = `
            <option value="">Seleccione producto</option>
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($producto->nombre); ?>"><?php echo e($producto->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        `;

        document.getElementById('agregar-trabajo').addEventListener('click', function () {
            const container = document.getElementById('trabajos-container');

            const nuevoTrabajo = document.createElement('div');
            nuevoTrabajo.classList.add('trabajo', 'border', 'p-3', 'mb-3');
            nuevoTrabajo.innerHTML = `
            <div class="mb-2">
                <label>Producto</label>
                <select name="trabajos[${index}][tipo]" class="form-control trabajo-input select2-producto" required>
                    ${productosOptions}
                </select>
            </div>
            <!-- resto de campos... -->`;
            container.appendChild(nuevoTrabajo);
            index++;

            $(nuevoTrabajo).find('.select2-producto').select2();
            actualizarPreview();
        });

        document.addEventListener('click', function (e) {
            // Marcar como terminado...
            // Eliminar trabajo...
        });

        function actualizarPreview() { /* ... */ }

        // Inicializar Select2 para los trabajos existentes
        document.addEventListener('DOMContentLoaded', function () {
            $('.select2-producto').each(function () {
                $(this).select2();
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\grafica-app\resources\views/ordenes-trabajo/edit.blade.php ENDPATH**/ ?>