<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('ordenes-trabajo.create')); ?>" class="gbtn gbtn-primary">+ Nueva orden</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:24px">

    <div class="gcard" style="border-top:2px solid #333">
        <div class="gcard-bd" style="padding:18px 20px">
            <div class="mono" style="font-size:30px;font-weight:500;color:#666;line-height:1;margin-bottom:5px"><?php echo e($contadores['borrador']); ?></div>
            <div style="font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:#444">Borrador</div>
        </div>
    </div>

    <div class="gcard" style="border-top:2px solid #d4900a">
        <div class="gcard-bd" style="padding:18px 20px">
            <div class="mono" style="font-size:30px;font-weight:500;color:#d4900a;line-height:1;margin-bottom:5px"><?php echo e($contadores['en_produccion']); ?></div>
            <div style="font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:#444">En producción</div>
        </div>
    </div>

    <div class="gcard" style="border-top:2px solid #4caf6e">
        <div class="gcard-bd" style="padding:18px 20px">
            <div class="mono" style="font-size:30px;font-weight:500;color:#4caf6e;line-height:1;margin-bottom:5px"><?php echo e($contadores['lista']); ?></div>
            <div style="font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:#444">Listas p/ entregar</div>
        </div>
    </div>

    <div class="gcard" style="border-top:2px solid #4a8fd4">
        <div class="gcard-bd" style="padding:18px 20px">
            <div class="mono" style="font-size:30px;font-weight:500;color:#4a8fd4;line-height:1;margin-bottom:5px"><?php echo e($contadores['entregada']); ?></div>
            <div style="font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:#444">Entregadas</div>
        </div>
    </div>

</div>


<div class="gcard">
    <div class="gcard-hd">
        <span class="gcard-title">Órdenes activas</span>
    </div>
    <?php if($ordenes->isEmpty()): ?>
        <div class="gcard-bd" style="text-align:center;color:#444;padding:48px 20px">
            No hay órdenes activas.
        </div>
    <?php else: ?>
        <table class="gtable">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Cliente</th>
                    <th>Fecha</th>
                    <th>Estado</th>
                    <th>Progreso</th>
                    <th>Trabajos</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $total      = $orden->trabajos->count();
                        $terminados = $orden->trabajos->whereIn('estado', ['terminado','entregado'])->count();
                        $pct        = $total > 0 ? round($terminados / $total * 100) : 0;
                    ?>
                    <tr>
                        <td class="mono" style="color:#555;font-size:12px">#<?php echo e(str_pad($orden->id, 3, '0', STR_PAD_LEFT)); ?></td>
                        <td>
                            <div style="font-weight:500"><?php echo e($orden->cliente->nombre ?? 'Sin cliente'); ?></div>
                            <?php if($orden->observaciones): ?>
                                <div style="font-size:12px;color:#555;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:220px"><?php echo e($orden->observaciones); ?></div>
                            <?php endif; ?>
                        </td>
                        <td class="mono txm" style="font-size:12px"><?php echo e(\Carbon\Carbon::parse($orden->fecha_recibido)->format('d/m/y')); ?></td>
                        <td>
                            <span class="badge-estado be-<?php echo e($orden->estado); ?>">
                                <?php echo e(['borrador'=>'Borrador','en_produccion'=>'En producción','lista'=>'Lista','entregada'=>'Entregada','cancelada'=>'Cancelada'][$orden->estado] ?? $orden->estado); ?>

                            </span>
                        </td>
                        <td style="min-width:130px">
                            <?php if($total > 0): ?>
                                <div class="gprog" style="margin-bottom:4px">
                                    <div class="gprog-fill <?php echo e($pct == 100 ? 'done' : ''); ?>" style="width:<?php echo e($pct); ?>%"></div>
                                </div>
                                <div class="mono" style="font-size:10px;color:#444"><?php echo e($terminados); ?>/<?php echo e($total); ?> trabajos</div>
                            <?php else: ?>
                                <span style="font-size:12px;color:#333">Sin trabajos</span>
                            <?php endif; ?>
                        </td>
                        <td style="max-width:180px">
                            <?php $__currentLoopData = $orden->trabajos->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div style="font-size:12px;color:#555">· <?php echo e($t->descripcion ?? $t->tipo ?? '—'); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($orden->trabajos->count() > 2): ?>
                                <div style="font-size:11px;color:#3a3a3a">+<?php echo e($orden->trabajos->count() - 2); ?> más</div>
                            <?php endif; ?>
                        </td>
                        <td style="text-align:right;white-space:nowrap">
                            <a href="<?php echo e(route('ordenes-trabajo.show', $orden->id)); ?>" class="gbtn gbtn-ghost gbtn-sm">Ver</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\grafica-app\resources\views/dashboard.blade.php ENDPATH**/ ?>